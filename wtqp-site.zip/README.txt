Walk the Quiet Path — static landing page

How to use
1) Push these files to your GitHub repo (e.g., walkthequietpath-site).
2) On Netlify: New Site from Git → select repo → Build command: none (this is a static site), Publish directory: / (root).
3) Point your domain DNS to Netlify when ready.
4) Update the form action in index.html to your Kit subscribe endpoint.

Key links
- Google Doc copy link: https://docs.google.com/document/d/1OPTWROJORC2nhKye26SE25fDjcclMEY/copy
- Thank-you page: /thank-you.html
- Privacy: /privacy.html
- Terms: /terms.html
